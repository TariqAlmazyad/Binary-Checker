//
//  ViewController.swift
//  binary checker
//
//  Created by Tariq Almazyad on 10/9/20.
//

import UIKit

class ViewController: UIViewController {
    
    private let resultLabel: UILabel = {
        let label = UILabel()
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.textColor = .black
        label.font = .systemFont(ofSize: 14)
        label.setDimensions(height: 50, width: 100)
        label.backgroundColor = .lightGray
        return label
    }()
    
    private let binaryLabel: UILabel = {
        let label = UILabel()
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.textColor = .black
        label.font = .systemFont(ofSize: 14)
        label.setDimensions(height: 50, width: 100)
        label.backgroundColor = .lightGray
        label.text = "Binary number"
        return label
    }()
    
    
    private lazy var viewResult: UIView = {
        let view = UIView()
        view.setDimensions(height: 50, width: 50)
        view.layer.cornerRadius = 50 / 2
        view.clipsToBounds = true
        view.backgroundColor = .clear
        return view
    }()
    
    private lazy var numberTextField: UITextField = {
        let textField = UITextField()
        textField.adjustsFontSizeToFitWidth = true
        textField.textAlignment = .center
        textField.textColor = .black
        textField.font = .systemFont(ofSize: 14)
        textField.setDimensions(height: 50, width: 200)
        let attributedPlaceholder  = NSAttributedString(string: "12345",
                                                        attributes:[.foregroundColor : UIColor.black.withAlphaComponent(0.3)])
        textField.attributedPlaceholder = attributedPlaceholder
        textField.backgroundColor = .lightGray
        textField.layer.cornerRadius = 20
        textField.delegate = self
        textField.keyboardType = .numberPad
        return textField
    }()
    
    private lazy var calculateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setDimensions(height: 50, width: 300)
        button.addTarget(self, action: #selector(handleCalculation), for: .touchUpInside)
        button.backgroundColor = .systemGreen
        button.layer.cornerRadius = 50 / 2
        button.setTitleColor(.white, for: .normal)
        button.setTitle("Calculate", for: .normal)
        return button
    }()
    
    private lazy var switcher1 = createSwitcher(tagNumber: 1)
    private lazy var switcher2 = createSwitcher(tagNumber: 2)
    private lazy var switcher3 = createSwitcher(tagNumber: 3)
    private lazy var switcher4 = createSwitcher(tagNumber: 4)
    private lazy var switcher5 = createSwitcher(tagNumber: 5)
    private lazy var switcher6 = createSwitcher(tagNumber: 6)
    private lazy var switcher7 = createSwitcher(tagNumber: 7)
    private lazy var switcher8 = createSwitcher(tagNumber: 8)
    
    private lazy var labelSwitcher1 = createLabel()
    private lazy var labelSwitcher2 = createLabel()
    private lazy var labelSwitcher3 = createLabel()
    private lazy var labelSwitcher4 = createLabel()
    private lazy var labelSwitcher5 = createLabel()
    private lazy var labelSwitcher6 = createLabel()
    private lazy var labelSwitcher7 = createLabel()
    private lazy var labelSwitcher8 = createLabel()
    
    var globalBinary: String = "00000000"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
        self.hideKeyboardWhenTouchOutsideTextField()
    }
    
    
    func configureUI(){
        view.addSubview(resultLabel)
        view.backgroundColor = #colorLiteral(red: 0.2156862745, green: 0.2156862745, blue: 0.2156862745, alpha: 1)
        resultLabel.centerX(inView: view, topAnchor: view.safeAreaLayoutGuide.topAnchor, paddingTop: 30)
        view.addSubview(binaryLabel)
        binaryLabel.centerY(inView: resultLabel, leftAnchor: resultLabel.rightAnchor, paddingLeft: 20)
        view.addSubview(numberTextField)
        numberTextField.centerX(inView: resultLabel, topAnchor: resultLabel.bottomAnchor, paddingTop: 30)
        
        view.addSubview(viewResult)
        viewResult.centerX(inView: numberTextField, topAnchor: numberTextField.bottomAnchor, paddingTop: 30)
        
        view.addSubview(calculateButton)
        
        
        let stackView = UIStackView(arrangedSubviews: [switcher1,
                                                       switcher2,
                                                       switcher3,
                                                       switcher4,
                                                       switcher5,
                                                       switcher6,
                                                       switcher7,
                                                       switcher8])
        stackView.axis = .vertical
        stackView.spacing = 12
        stackView.distribution = .fillEqually
        
        let stackViewLabels = UIStackView(arrangedSubviews: [labelSwitcher1,
                                                             labelSwitcher2,
                                                             labelSwitcher3,
                                                             labelSwitcher4,
                                                             labelSwitcher5,
                                                             labelSwitcher6,
                                                             labelSwitcher7,
                                                             labelSwitcher8,])
        stackViewLabels.axis = .vertical
        stackViewLabels.spacing = 12
        stackViewLabels.distribution = .fillEqually
        
        let mainStackView = UIStackView(arrangedSubviews: [stackView, stackViewLabels])
        mainStackView.axis = .horizontal
        mainStackView.spacing = 40
        mainStackView.distribution = .fillEqually
        view.addSubview(mainStackView)
        mainStackView.centerX(inView: numberTextField, topAnchor: viewResult.bottomAnchor, paddingTop: 20)
        calculateButton.anchor(top: mainStackView.bottomAnchor, paddingTop: 20)
        calculateButton.centerX(inView: mainStackView)
        
    }
    
    @objc func handleSwitcher(_ sender: UISwitch){
        
        switch sender.tag {
        case 1:
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 7, newChar: "1")
                labelSwitcher1.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 7, newChar: "0")
                labelSwitcher1.text = "\(0)"
            }
        case 2:
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 6, newChar: "1")
                labelSwitcher2.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 6, newChar: "0")
                labelSwitcher2.text = "\(0)"
            }
        case 3:
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 5, newChar: "1")
                labelSwitcher3.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 5, newChar: "0")
                labelSwitcher3.text = "\(0)"
            }
            
        case 4 :
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 4, newChar: "1")
                labelSwitcher4.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 4, newChar: "0")
                labelSwitcher4.text = "\(0)"
            }
        case 5:
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 3, newChar: "1")
                labelSwitcher5.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 3, newChar: "0")
                labelSwitcher5.text = "\(0)"
            }
            
        case 6:
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 2, newChar: "1")
                labelSwitcher6.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 2, newChar: "0")
                labelSwitcher6.text = "\(0)"
            }
        case 7:
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 1, newChar: "1")
                labelSwitcher7.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 1, newChar: "0")
                labelSwitcher7.text = "\(0)"
            }
            
        case 8:
            if sender.isOn {
                globalBinary = replace(myString: globalBinary, index: 0, newChar: "1")
                labelSwitcher8.text = "\(1)"
            } else {
                globalBinary =  replace(myString: globalBinary, index: 0, newChar: "0")
                labelSwitcher8.text = "\(0)"
            }
            
        default:
            break
        }
        
    }
    
    func replace(myString: String, index: Int, newChar: Character) -> String {
        
        var modifiedString = String()
        
        for (i, char) in myString.enumerated() {
            
            print(i , char)
            
            modifiedString += String((i == index) ? newChar : char)
            
        }
        return modifiedString
    }
    
    
    
    @objc func handleCalculation(){
        
        guard let result = numberTextField.text else { return  }
        let number = strtoul(globalBinary, nil, 2)
        
        resultLabel.text = globalBinary
        
        if Int(number) == Int(result) {
            viewResult.backgroundColor = .systemGreen
            self.showAlertMessage("Correct!", "Nice, you got it!\n \(globalBinary) = \(result) in binary")
        } else {
            viewResult.backgroundColor = .red
            self.showAlertMessage("almost!!", "\(globalBinary) does not equal \(result) in binary")
        }
        
    }
    
    func createSwitcher(tagNumber: Int) -> UISwitch {
        let switcher = UISwitch()
        switcher.tag = tagNumber
        switcher.addTarget(self, action: #selector(handleSwitcher), for: .valueChanged)
        return switcher
    }
    
    func createLabel() -> UILabel {
        let label = UILabel()
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.textColor = .black
        label.font = .systemFont(ofSize: 14)
        label.setDimensions(height: 30, width: 40)
        label.layer.cornerRadius = 10
        label.backgroundColor = .lightGray
        label.text = "0"
        return label
    }
    
}


extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return true
    }
}
